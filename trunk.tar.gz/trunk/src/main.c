#include <stdio.h>
#include "ag.h"

int main()
{
    //int i;

    AG();

    return 0;
}
